import { motion } from 'motion/react';
import { ArrowLeft, Eye, Calendar, Video } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';

interface ResultsHistoryProps {
  onBack: () => void;
  onViewDetails?: (testDate: string, videoCount: number) => void;
}

export function ResultsHistory({ onBack, onViewDetails }: ResultsHistoryProps) {
  const testHistory = [
    {
      id: 1,
      testName: 'Full Blind Test - Marketing Videos',
      date: '2025-10-23',
      time: '14:35',
      videosProcessed: 12,
      duration: '8 min',
      highRisk: 3,
      uncertain: 4,
      lowRisk: 5,
    },
    {
      id: 2,
      testName: 'Instant Test - Product Launch',
      date: '2025-10-22',
      time: '11:20',
      videosProcessed: 1,
      duration: '45 sec',
      highRisk: 0,
      uncertain: 0,
      lowRisk: 1,
    },
    {
      id: 3,
      testName: 'Full Blind Test - Q4 Campaign',
      date: '2025-10-21',
      time: '16:45',
      videosProcessed: 8,
      duration: '5 min',
      highRisk: 2,
      uncertain: 2,
      lowRisk: 4,
    },
    {
      id: 4,
      testName: 'Full Blind Test - Social Media Content',
      date: '2025-10-20',
      time: '09:15',
      videosProcessed: 15,
      duration: '10 min',
      highRisk: 5,
      uncertain: 3,
      lowRisk: 7,
    },
    {
      id: 5,
      testName: 'Instant Test - Brand Video',
      date: '2025-10-19',
      time: '13:30',
      videosProcessed: 1,
      duration: '42 sec',
      highRisk: 1,
      uncertain: 0,
      lowRisk: 0,
    },
    {
      id: 6,
      testName: 'Full Blind Test - Training Videos',
      date: '2025-10-18',
      time: '10:00',
      videosProcessed: 20,
      duration: '13 min',
      highRisk: 1,
      uncertain: 5,
      lowRisk: 14,
    },
    {
      id: 7,
      testName: 'Full Blind Test - Customer Testimonials',
      date: '2025-10-17',
      time: '15:20',
      videosProcessed: 10,
      duration: '7 min',
      highRisk: 0,
      uncertain: 2,
      lowRisk: 8,
    },
  ];

  return (
    <div className="min-h-[calc(100vh-73px)] bg-gradient-to-br from-[#1A1F25] via-[#0F1419] to-[#1A1F25] p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h2 className="text-white text-2xl md:text-3xl mb-2">Test History</h2>
              <p className="text-gray-400">View all completed classification tests</p>
            </div>
          </div>
        </motion.div>

        {/* Stats Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6"
        >
          <Card className="bg-[#1F2937]/50 backdrop-blur-xl border-gray-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-gray-400 text-sm">Total Tests</p>
                <Video className="w-4 h-4 text-[#00D9FF]" />
              </div>
              <p className="text-white text-2xl">{testHistory.length}</p>
              <p className="text-gray-500 text-xs mt-1">Completed successfully</p>
            </CardContent>
          </Card>
          <Card className="bg-[#1F2937]/50 backdrop-blur-xl border-gray-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-gray-400 text-sm">Videos Analyzed</p>
                <Video className="w-4 h-4 text-purple-400" />
              </div>
              <p className="text-white text-2xl">
                {testHistory.reduce((sum, test) => sum + test.videosProcessed, 0)}
              </p>
              <p className="text-gray-500 text-xs mt-1">Total processed</p>
            </CardContent>
          </Card>
          <Card className="bg-[#1F2937]/50 backdrop-blur-xl border-gray-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-gray-400 text-sm">Latest Test</p>
                <Calendar className="w-4 h-4 text-green-400" />
              </div>
              <p className="text-white text-2xl">{testHistory[0].date}</p>
              <p className="text-gray-500 text-xs mt-1">{testHistory[0].time}</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Test History Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-[#1F2937]/50 backdrop-blur-xl border-gray-800">
            <CardContent className="p-0">
              {/* Desktop Table View */}
              <div className="hidden lg:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-800 hover:bg-transparent">
                      <TableHead className="text-gray-400">Test Name</TableHead>
                      <TableHead className="text-gray-400 text-center">Date</TableHead>
                      <TableHead className="text-gray-400 text-center">Videos</TableHead>
                      <TableHead className="text-gray-400 text-center">Duration</TableHead>
                      <TableHead className="text-gray-400 text-center">Results Summary</TableHead>
                      <TableHead className="text-gray-400 text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {testHistory.map((test, index) => (
                      <motion.tr
                        key={test.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: index * 0.05 }}
                        className="border-gray-800 hover:bg-gray-800/30 transition-colors"
                      >
                        <TableCell className="text-white">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#00D9FF]/20 to-[#0099FF]/20 flex items-center justify-center">
                              <Video className="w-5 h-5 text-[#00D9FF]" />
                            </div>
                            <div>
                              <p className="text-white">{test.testName}</p>
                              <p className="text-gray-500 text-xs">{test.time}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-300 text-center">{test.date}</TableCell>
                        <TableCell className="text-gray-300 text-center">{test.videosProcessed}</TableCell>
                        <TableCell className="text-gray-300 text-center">{test.duration}</TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center gap-2 text-xs">
                            <span className="px-2 py-1 bg-red-500/20 text-red-400 rounded">
                              {test.highRisk} High
                            </span>
                            <span className="px-2 py-1 bg-orange-500/20 text-orange-400 rounded">
                              {test.uncertain} Unc.
                            </span>
                            <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded">
                              {test.lowRisk} Low
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <Button
                            onClick={() => onViewDetails?.(test.date, test.videosProcessed)}
                            variant="outline"
                            size="sm"
                            className="border-[#00D9FF]/50 text-[#00D9FF] hover:bg-[#00D9FF]/10 hover:border-[#00D9FF] rounded-lg"
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </Button>
                        </TableCell>
                      </motion.tr>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="lg:hidden divide-y divide-gray-800">
                {testHistory.map((test, index) => (
                  <motion.div
                    key={test.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.05 }}
                    className="p-4"
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#00D9FF]/20 to-[#0099FF]/20 flex items-center justify-center flex-shrink-0">
                        <Video className="w-5 h-5 text-[#00D9FF]" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white mb-1">{test.testName}</p>
                        <p className="text-gray-400 text-sm">
                          {test.date} • {test.time}
                        </p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 mb-3 text-sm">
                      <div>
                        <p className="text-gray-500 mb-1">Videos</p>
                        <p className="text-gray-300">{test.videosProcessed}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Duration</p>
                        <p className="text-gray-300">{test.duration}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-3 text-xs flex-wrap">
                      <span className="px-2 py-1 bg-red-500/20 text-red-400 rounded">
                        {test.highRisk} High Risk
                      </span>
                      <span className="px-2 py-1 bg-orange-500/20 text-orange-400 rounded">
                        {test.uncertain} Uncertain
                      </span>
                      <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded">
                        {test.lowRisk} Low Risk
                      </span>
                    </div>

                    <Button
                      onClick={() => onViewDetails?.(test.date, test.videosProcessed)}
                      variant="outline"
                      size="sm"
                      className="w-full border-[#00D9FF]/50 text-[#00D9FF] hover:bg-[#00D9FF]/10 hover:border-[#00D9FF] rounded-lg"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View Details
                    </Button>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
