import { motion } from 'motion/react';
import { ArrowLeft, Download } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';

interface ClassificationResultsProps {
  onBack: () => void;
  testDate?: string;
  videosProcessed?: number;
}

export function ClassificationResults({ onBack, testDate, videosProcessed }: ClassificationResultsProps) {
  const results = [
    {
      id: 1,
      video: 'Sample Video A',
      mathClassifier: '78%',
      dlClassifier: '82%',
      finalResult: 85,
      status: 'high-risk',
    },
    {
      id: 2,
      video: 'Sample Video B',
      mathClassifier: '45%',
      dlClassifier: '52%',
      finalResult: 48,
      status: 'uncertain',
    },
    {
      id: 3,
      video: 'Sample Video C',
      mathClassifier: '12%',
      dlClassifier: '18%',
      finalResult: 15,
      status: 'low-risk',
    },
    {
      id: 4,
      video: 'Sample Video D',
      mathClassifier: 'N/A',
      dlClassifier: 'N/A',
      finalResult: 0,
      status: 'error',
    },
    {
      id: 5,
      video: 'Sample Video E',
      mathClassifier: '88%',
      dlClassifier: '91%',
      finalResult: 90,
      status: 'high-risk',
    },
    {
      id: 6,
      video: 'Sample Video F',
      mathClassifier: '25%',
      dlClassifier: '20%',
      finalResult: 22,
      status: 'low-risk',
    },
    {
      id: 7,
      video: 'Sample Video G',
      mathClassifier: '55%',
      dlClassifier: '48%',
      finalResult: 51,
      status: 'uncertain',
    },
  ];

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'high-risk':
        return {
          label: 'High Risk',
          className: 'bg-red-500/20 text-red-400 border-red-500/30',
        };
      case 'uncertain':
        return {
          label: 'Uncertain',
          className: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
        };
      case 'low-risk':
        return {
          label: 'Low Risk',
          className: 'bg-green-500/20 text-green-400 border-green-500/30',
        };
      case 'error':
        return {
          label: 'Video Error',
          className: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
        };
      default:
        return {
          label: 'Unknown',
          className: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
        };
    }
  };

  const handleDownloadReport = () => {
    // Generate report content
    const reportContent = `GMA CLASSIFIER - CLASSIFICATION REPORT
================================================

Test Details:
-------------
Model Used: YOLO v8
Date: ${testDate || new Date().toLocaleDateString()}
Videos Processed: ${videosProcessed || results.length}
Total Time Taken: 5 min
Time Per Video: 40 sec

Classification Results:
----------------------
${results.slice(0, videosProcessed || results.length).map((result, index) => `
${index + 1}. ${result.video}
   Math Classifier: ${result.mathClassifier}
   DL Classifier: ${result.dlClassifier}
   Final Result: ${result.finalResult}%
   Status: ${getStatusConfig(result.status).label}
`).join('')}

Summary:
--------
High Risk: ${results.slice(0, videosProcessed || results.length).filter(r => r.status === 'high-risk').length}
Uncertain: ${results.slice(0, videosProcessed || results.length).filter(r => r.status === 'uncertain').length}
Low Risk: ${results.slice(0, videosProcessed || results.length).filter(r => r.status === 'low-risk').length}
Errors: ${results.slice(0, videosProcessed || results.length).filter(r => r.status === 'error').length}

================================================
Report Generated: ${new Date().toLocaleString()}
`;

    // Create and download the file
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `GMA_Classification_Report_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    // Navigate to dashboard after brief delay
    setTimeout(() => {
      onBack();
    }, 500);
  };

  return (
    <div className="min-h-[calc(100vh-73px)] bg-gradient-to-br from-[#1A1F25] via-[#0F1419] to-[#1A1F25] p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to History
          </button>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h2 className="text-white text-2xl md:text-3xl mb-2">Classification Results</h2>
              <p className="text-gray-400">Per video classification details</p>
            </div>
            <Button 
              onClick={handleDownloadReport}
              className="bg-gradient-to-r from-[#00D9FF] to-[#0099FF] hover:from-[#00BFFF] hover:to-[#0088EE] text-white rounded-xl shadow-lg shadow-[#00D9FF]/30 transition-all duration-200 hover:scale-[1.02]"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Report
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Results Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2"
          >
            <Card className="bg-[#1F2937]/50 backdrop-blur-xl border-gray-800">
              <CardContent className="p-0">
                {/* Desktop Table View */}
                <div className="hidden md:block overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-800 hover:bg-transparent">
                        <TableHead className="text-gray-400 w-1/4">Video</TableHead>
                        <TableHead className="text-gray-400 w-1/4 text-center">Math Classifier</TableHead>
                        <TableHead className="text-gray-400 w-1/4 text-center">DL Classifier</TableHead>
                        <TableHead className="text-gray-400 w-1/4 text-center">Final Result</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {results.slice(0, videosProcessed || results.length).map((result, index) => {
                        const statusConfig = getStatusConfig(result.status);
                        return (
                          <motion.tr
                            key={result.id}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: index * 0.05 }}
                            className="border-gray-800 hover:bg-gray-800/30 transition-colors"
                          >
                            <TableCell className="text-white">{result.video}</TableCell>
                            <TableCell className="text-gray-300 text-center">{result.mathClassifier}</TableCell>
                            <TableCell className="text-gray-300 text-center">{result.dlClassifier}</TableCell>
                            <TableCell>
                              <div className="flex items-center justify-center gap-3">
                                <span className="text-white min-w-[3rem] text-center">{result.finalResult}%</span>
                                <Badge
                                  variant="outline"
                                  className={`rounded-lg ${statusConfig.className} min-w-[7rem] justify-center`}
                                >
                                  {statusConfig.label}
                                </Badge>
                              </div>
                            </TableCell>
                          </motion.tr>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>

                {/* Mobile Card View */}
                <div className="md:hidden">
                  {results.slice(0, videosProcessed || results.length).map((result, index) => {
                    const statusConfig = getStatusConfig(result.status);
                    return (
                      <motion.div
                        key={result.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: index * 0.05 }}
                        className="p-4 border-b border-gray-800"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <p className="text-white">{result.video}</p>
                          <Badge
                            variant="outline"
                            className={`rounded-lg ${statusConfig.className}`}
                          >
                            {statusConfig.label}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-sm">
                          <div>
                            <p className="text-gray-500 mb-1">Math</p>
                            <p className="text-gray-300">{result.mathClassifier}</p>
                          </div>
                          <div>
                            <p className="text-gray-500 mb-1">DL</p>
                            <p className="text-gray-300">{result.dlClassifier}</p>
                          </div>
                          <div>
                            <p className="text-gray-500 mb-1">Final</p>
                            <p className="text-white">{result.finalResult}%</p>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Details Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-1"
          >
            <Card className="bg-[#1F2937]/50 backdrop-blur-xl border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Test Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Card className="bg-[#0F1419] border-gray-800">
                  <CardContent className="p-4">
                    <p className="text-gray-400 text-sm mb-1">Model Used</p>
                    <p className="text-white">YOLO v8</p>
                  </CardContent>
                </Card>

                <Card className="bg-[#0F1419] border-gray-800">
                  <CardContent className="p-4">
                    <p className="text-gray-400 text-sm mb-1">Date</p>
                    <p className="text-white">{testDate || '20/10/2025'}</p>
                  </CardContent>
                </Card>

                <Card className="bg-[#0F1419] border-gray-800">
                  <CardContent className="p-4">
                    <p className="text-gray-400 text-sm mb-1">Total Time Taken</p>
                    <p className="text-white">5 min</p>
                  </CardContent>
                </Card>

                <Card className="bg-[#0F1419] border-gray-800">
                  <CardContent className="p-4">
                    <p className="text-gray-400 text-sm mb-1">Time Per Video</p>
                    <p className="text-white">40 sec</p>
                  </CardContent>
                </Card>

                <Card className="bg-[#0F1419] border-gray-800">
                  <CardContent className="p-4">
                    <p className="text-gray-400 text-sm mb-1">Videos Processed</p>
                    <p className="text-white">{videosProcessed || results.length}</p>
                  </CardContent>
                </Card>

                {/* Status Legend */}
                <div className="pt-6 border-t border-gray-800">
                  <p className="text-gray-400 text-sm mb-3">Status Legend</p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500" />
                      <span className="text-gray-300 text-sm">High Risk (≥70%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-orange-500" />
                      <span className="text-gray-300 text-sm">Uncertain (40-70%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500" />
                      <span className="text-gray-300 text-sm">Low Risk {'(<40%)'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-gray-500" />
                      <span className="text-gray-300 text-sm">Video Error</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
