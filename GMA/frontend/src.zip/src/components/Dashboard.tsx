import { motion } from 'motion/react';
import { Upload, FolderOpen, History, FlaskConical, BarChart3 } from 'lucide-react';
import { Card, CardDescription, CardHeader, CardTitle } from './ui/card';

interface DashboardProps {
  onNavigate: (screen: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const tiles = [
    {
      id: 'upload',
      title: 'Video Upload',
      description: 'Upload new videos for classification',
      icon: Upload,
      gradient: 'from-[#00D9FF] to-[#0099FF]',
    },
    {
      id: 'manage',
      title: 'Manage Uploads',
      description: 'View and organize your videos',
      icon: FolderOpen,
      gradient: 'from-[#0099FF] to-[#6B5FFF]',
    },
    {
      id: 'history',
      title: 'History',
      description: 'View classification results',
      icon: History,
      gradient: 'from-[#6B5FFF] to-[#9D5FFF]',
    },
    {
      id: 'blind-test',
      title: 'Blind Test',
      description: 'Run full blind test on videos',
      icon: FlaskConical,
      gradient: 'from-[#9D5FFF] to-[#FF5FBF]',
    }
  ];

  return (
    <div className="min-h-[calc(100vh-73px)] bg-gradient-to-br from-[#161F27] via-[#191D23] to-[#161F27] p-4 md:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-white text-3xl md:text-4xl font-bold mb-2">Welcome Back!</h1>
          <p className="text-gray-400 text-lg">
            Select an option to get started with video classification
          </p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {tiles.map((tile, idx) => {
            const Icon = tile.icon;
            return (
              <motion.div
                key={tile.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * idx }}
              >
                <Card
                  onClick={() => onNavigate(tile.id)}
                  className="cursor-pointer dark:bg-[#232B34]/50 bg-[#1e293b]/80 hover:shadow-xl dark:border-gray-800 border border-gray-700 rounded-2xl transition-shadow group"
                >
                  <CardHeader className="pb-3 flex flex-row items-center gap-4">
                    <div
                      className={`w-16 h-16 bg-gradient-to-br ${tile.gradient} rounded-xl flex items-center justify-center shadow-lg shadow-black/20 group-hover:scale-105 transition-transform`}
                    >
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-white text-2xl mb-1 leading-snug">{tile.title}</CardTitle>
                      <CardDescription className="text-gray-400 text-sm">
                        {tile.description}
                      </CardDescription>
                    </div>
                  </CardHeader>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
