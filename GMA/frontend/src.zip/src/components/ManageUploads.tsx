import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  Search,
  MoreVertical,
  Trash2,
  Download,
  Eye,
  CheckSquare,
  Square,
  Calendar,
  Clock,
  FileVideo,
  AlertCircle,
  Loader,
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { toast } from 'sonner';
import { useAuth } from '../contexts/AuthContext';

interface ManageUploadsProps {
  onBack: () => void;
  onInstantBlindTest?: () => void;
}

interface Video {
  id: number;
  filename: string;
  original_filename: string;
  file_size: number;
  status: 'uploaded' | 'processing' | 'completed' | 'error';
  created_at: string;
  classification?: 'high-risk' | 'uncertain' | 'low-risk';
  confidence?: number;
}

export function ManageUploads({ onBack, onInstantBlindTest }: ManageUploadsProps) {
  const { currentUser } = useAuth();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVideos, setSelectedVideos] = useState<number[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // ✅ Fetch videos from backend
  useEffect(() => {
    const fetchVideos = async () => {
      if (!currentUser) {
        setLoading(false);
        return;
      }

      try {
        const token = await currentUser.getIdToken();
        const response = await fetch('http://localhost:8000/api/uploads/', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch videos');
        }

        const data = await response.json();
        setVideos(data);
      } catch (error) {
        console.error('Error fetching videos:', error);
        toast.error('Failed to load videos');
      } finally {
        setLoading(false);
      }
    };

    fetchVideos();
  }, [currentUser]);

  // ✅ Format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  // ✅ Format date
  const formatDate = (dateString: string): string => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      });
    } catch {
      return dateString;
    }
  };

  // ✅ Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'uploaded':
        return <Badge className="bg-blue-500/20 text-blue-400">Uploaded</Badge>;
      case 'processing':
        return <Badge className="bg-yellow-500/20 text-yellow-400">Processing</Badge>;
      case 'completed':
        return <Badge className="bg-green-500/20 text-green-400">Completed</Badge>;
      case 'error':
        return <Badge className="bg-red-500/20 text-red-400">Error</Badge>;
      default:
        return <Badge className="bg-gray-500/20 text-gray-400">Unknown</Badge>;
    }
  };

  // ✅ Get classification badge
  const getClassificationBadge = (classification?: string) => {
    switch (classification) {
      case 'high-risk':
        return <Badge className="bg-red-500/20 text-red-400">High Risk</Badge>;
      case 'uncertain':
        return <Badge className="bg-yellow-500/20 text-yellow-400">Uncertain</Badge>;
      case 'low-risk':
        return <Badge className="bg-green-500/20 text-green-400">Low Risk</Badge>;
      default:
        return <Badge className="bg-gray-500/20 text-gray-400">Not Classified</Badge>;
    }
  };

  const filteredVideos = videos.filter((video) =>
    video.original_filename.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleVideoSelection = (id: number) => {
    setSelectedVideos((prev) =>
      prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedVideos.length === filteredVideos.length) {
      setSelectedVideos([]);
    } else {
      setSelectedVideos(filteredVideos.map((v) => v.id));
    }
  };

  // ✅ Delete video
  const handleDeleteSingle = async (id: number) => {
    if (!currentUser) {
      toast.error('Not authenticated');
      return;
    }

    try {
      const token = await currentUser.getIdToken();
      const response = await fetch(`http://localhost:8000/api/uploads/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to delete video');
      }

      setVideos((prev) => prev.filter((v) => v.id !== id));
      toast.success('Video deleted successfully');
    } catch (error) {
      console.error('Error deleting video:', error);
      toast.error('Failed to delete video');
    }
  };

  // ManageUploads.tsx (Modified handleDeleteSelected for robustness)

  const handleDeleteSelected = async () => {
    if (!currentUser) {
      toast.error('Not authenticated');
      return;
    }

    try {
      const token = await currentUser.getIdToken();
      
      // Use map to create an array of promises, but catch individual errors
      const deletePromises = selectedVideos.map((id) =>
          fetch(`http://localhost:8000/api/uploads/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` },
          }).then(response => {
            if (!response.ok) {
                // If deletion failed on backend, throw an error with ID
                throw new Error(`Failed to delete ID ${id}`);
            }
            return id; // Return the successfully deleted ID
          }).catch(error => {
            console.error(error.message);
            // Return null or a sentinel value instead of re-throwing, 
            // so Promise.all completes.
            return null; 
          })
      );
      
      const results = await Promise.all(deletePromises);
      
      // Filter out null results (failed deletions) to get only successful IDs
      const successfulDeletions = results.filter((id): id is number => id !== null);

      // Update state to remove only the successfully deleted videos
      setVideos((prev) => 
        prev.filter((v) => !successfulDeletions.includes(v.id))
      );

      setSelectedVideos([]);
      setShowDeleteDialog(false);
      
      if (successfulDeletions.length > 0) {
        toast.success(`${successfulDeletions.length} video(s) deleted successfully`);
      } else {
        toast.error('No videos were deleted. Check console for details.');
      }

    } catch (error) {
      console.error('Error during batch deletion:', error);
      toast.error('An unexpected error occurred during batch deletion.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-[calc(100vh-73px)] dark:bg-[#1A1F25] bg-gray-50 p-4 md:p-8 flex items-center justify-center">
        <div className="flex items-center gap-2 dark:text-white text-gray-900">
          <Loader className="w-5 h-5 animate-spin" />
          Loading videos...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-73px)] dark:bg-[#1A1F25] bg-gray-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-4 dark:text-gray-400 text-gray-600 dark:hover:text-white hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="dark:text-white text-gray-900 text-3xl font-bold mb-2">
            Manage Uploads
          </h1>
          <p className="dark:text-gray-400 text-gray-600">
            {videos.length} total videos • {selectedVideos.length} selected
          </p>
        </motion.div>

        {/* Batch Actions */}
        {selectedVideos.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 flex gap-2"
          >
            <Button
              onClick={() => setShowDeleteDialog(true)}
              variant="outline"
              className="border-red-500/50 text-red-400 hover:bg-red-500/10 hover:border-red-500 rounded-xl"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete ({selectedVideos.length})
            </Button>
          </motion.div>
        )}

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-6 relative"
        >
          <Search className="absolute left-4 top-3.5 w-5 h-5 dark:text-gray-500 text-gray-400" />
          <Input
            type="text"
            placeholder="Search videos by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 dark:bg-[#0F1419] bg-white dark:border-gray-700 border-gray-300 dark:text-white text-gray-900 placeholder:dark:text-gray-500 placeholder:text-gray-400 rounded-xl h-12 dark:focus:border-[#00D9FF] focus:ring-[#00D9FF]/20"
          />
        </motion.div>

        {/* Videos Table */}
        {filteredVideos.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <FileVideo className="w-12 h-12 dark:text-gray-600 text-gray-400 mx-auto mb-4 opacity-50" />
            <p className="dark:text-gray-400 text-gray-600 text-lg">
              {videos.length === 0 ? 'No videos uploaded yet' : 'No videos match your search'}
            </p>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="dark:bg-[#232B34] bg-white dark:border-gray-800 border-gray-200 border rounded-lg overflow-hidden"
          >
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="dark:border-gray-800 border-gray-200 border-b">
                    <th className="p-4 text-left">
                      <button
                        onClick={toggleSelectAll}
                        className="dark:text-gray-400 text-gray-600 hover:dark:text-white hover:text-gray-900 transition-colors"
                      >
                        {selectedVideos.length === filteredVideos.length && filteredVideos.length > 0 ? (
                          <CheckSquare className="w-5 h-5" />
                        ) : (
                          <Square className="w-5 h-5" />
                        )}
                      </button>
                    </th>
                    <th className="p-4 text-left dark:text-gray-300 text-gray-700 font-semibold">
                      Video Name
                    </th>
                    <th className="p-4 text-left dark:text-gray-300 text-gray-700 font-semibold">
                      Upload Date
                    </th>
                    <th className="p-4 text-left dark:text-gray-300 text-gray-700 font-semibold">
                      Size
                    </th>
                    <th className="p-4 text-left dark:text-gray-300 text-gray-700 font-semibold">
                      Status
                    </th>
                    <th className="p-4 text-left dark:text-gray-300 text-gray-700 font-semibold">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence>
                    {filteredVideos.map((video, index) => (
                      <motion.tr
                        key={video.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="dark:border-gray-800 border-gray-200 border-b dark:hover:bg-gray-800/50 hover:bg-gray-50 transition-colors"
                      >
                        <td className="p-4">
                          <button
                            onClick={() => toggleVideoSelection(video.id)}
                            className="dark:text-gray-400 text-gray-600 hover:dark:text-white hover:text-gray-900 transition-colors"
                          >
                            {selectedVideos.includes(video.id) ? (
                              <CheckSquare className="w-5 h-5" />
                            ) : (
                              <Square className="w-5 h-5" />
                            )}
                          </button>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <FileVideo className="w-4 h-4 dark:text-cyan-400 text-cyan-600" />
                            <div>
                              <p className="dark:text-white text-gray-900 font-medium truncate">
                                {video.original_filename}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 dark:text-gray-400 text-gray-600">
                          {formatDate(video.created_at)}
                        </td>
                        <td className="p-4 dark:text-gray-400 text-gray-600">
                          {formatFileSize(video.file_size)}
                        </td>
                        <td className="p-4">{getStatusBadge(video.status)}</td>
                        <td className="p-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger >
                              <Button
                                variant="ghost"
                                size="sm"
                                className="dark:text-gray-400 text-gray-600"
                              >
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="dark:bg-[#232B34] bg-white dark:border-gray-800 border-gray-200">
                              <DropdownMenuItem
                                onClick={() => setSelectedVideo(video)}
                                className="dark:hover:bg-gray-800 hover:bg-gray-100 cursor-pointer"
                              >
                                <Eye className="w-4 h-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDeleteSingle(video.id)}
                                className="dark:text-red-400 text-red-600 dark:hover:bg-red-500/10 hover:bg-red-50 cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* Video Details Dialog */}
        <Dialog open={selectedVideo !== null} onOpenChange={() => setSelectedVideo(null)}>
          <DialogContent className="dark:bg-[#232B34] bg-white dark:border-gray-800 border-gray-200">
            <DialogHeader>
              <DialogTitle className="dark:text-white text-gray-900">Video Details</DialogTitle>
              <DialogDescription className="dark:text-gray-400 text-gray-600">
                Detailed information about the selected video
              </DialogDescription>
            </DialogHeader>
            {selectedVideo && (
              <div className="space-y-4">
                <div>
                  <p className="dark:text-gray-400 text-gray-600 text-sm">Video Name</p>
                  <p className="dark:text-white text-gray-900 font-semibold">{selectedVideo.original_filename}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="dark:text-gray-400 text-gray-600 text-sm">Upload Date</p>
                    <p className="dark:text-white text-gray-900 font-semibold">
                      {formatDate(selectedVideo.created_at)}
                    </p>
                  </div>
                  <div>
                    <p className="dark:text-gray-400 text-gray-600 text-sm">File Size</p>
                    <p className="dark:text-white text-gray-900 font-semibold">
                      {formatFileSize(selectedVideo.file_size)}
                    </p>
                  </div>
                </div>
                <div>
                  <p className="dark:text-gray-400 text-gray-600 text-sm">Status</p>
                  {getStatusBadge(selectedVideo.status)}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent className="dark:bg-[#232B34] bg-white dark:border-gray-800 border-gray-200">
            <DialogHeader>
              <DialogTitle className="dark:text-white text-gray-900">Delete Videos</DialogTitle>
              <DialogDescription className="dark:text-gray-400 text-gray-600">
                Are you sure you want to delete {selectedVideos.length} video(s)? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <div className="flex gap-3 justify-end">
              <Button
                onClick={() => setShowDeleteDialog(false)}
                variant="outline"
                className="dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 hover:dark:text-white"
              >
                Cancel
              </Button>
              <Button
                onClick={handleDeleteSelected}
                className="bg-red-600 text-white hover:bg-red-700"
              >
                Delete
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
